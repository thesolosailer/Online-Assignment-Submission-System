<?php

$dbcon=mysqli_connect("localhost","root","");

mysqli_select_db($dbcon,"users");

?>